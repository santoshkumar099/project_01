package com.cts.service;

import com.cts.model.EPICs;

public interface EPICsService {
 String addEpic(EPICs epic);
}
