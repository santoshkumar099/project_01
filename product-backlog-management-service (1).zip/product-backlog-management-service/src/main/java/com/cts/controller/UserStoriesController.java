package com.cts.controller;

class UserStoriesController {

}
